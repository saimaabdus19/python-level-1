#Output to user
conversion_choice= input("1) lb to Kg, 2) Kg to lb")


#if user chooses lb to kg
if(conversion_choice == "1"):
  pounds= int(input("How many lb fo you want to convert?"))
  print("This is", pounds/2.204, " Kg ")
elif():
  kilos = int(input("How many Kg do you want to convert?"))
  print("This is ", kilos*2.204, " lb ")
  
else:
  print=("No options chosen")
  

