print("This program is a simple calculator that can multiply 2 numbers together")
first_num = int(input("Please enter your first number: "))
second_num = int(input("Please enter your second number: "))
total = first_num * second_num
print(f"The product of {first_num} * {second_num} = {total}")